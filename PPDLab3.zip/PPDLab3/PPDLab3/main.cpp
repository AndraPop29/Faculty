//
//  main.cpp
//  PPDLab3
//
//  Created by Andra on 30/10/2017.
//  Copyright © 2017 andrapop. All rights reserved.
//

#include <iostream>
#include <future>
#import "ThreadPool.cpp"

using namespace std;

int n = 0;
int m = 0;
int k = 0;
int **result;

void multiplyMatrices(int x, int y, int **a, int **b) {

    for(int i = x ; i < y ; i ++ )
        for(int j = 0 ; j < m; j ++) {
            for (int g = 0; g < k; g++) {
                result[i][j] += a[i][g] * b[g][j];
            }
        }

}
void printMatrix(int **a, int x, int y) {

    for(int i=0; i<x; i++) {
        for(int j=0; j<y; j++) {
            cout<<result[i][j]<<" ";
        }
        cout<<endl;
    }
    
}
int main(int argc, const char * argv[]) {
    cout << "Enter a number of threads";
    cin>>n;
    cout << "Number of lines for the first matrix: ";
    cin>>m;
    cout << "Number of columns for the first matrix: ";
    cin>>k;
    int **a = new int*[m];
    for(int i = 0; i < m; ++i) {
        a[i] = new int[k];
    }
    
    int **b = new int*[k];
    for(int i = 0; i < k; ++i) {
        b[i] = new int[m];
    }
    
    result = new int*[m];
    for(int i = 0; i < m; ++i) {
        result[i] = new int[m];
    }
    
    for(int i = 0; i < m ; i++) {
        for(int j = 0; j < k; j++) {
            a[i][j] = rand() % 10;
        }
    }
    
    for(int i = 0; i < k ; i++) {
        for(int j = 0; j < m; j++) {
            b[i][j] = rand() % 10;
        }
    }
    
    for(int i = 0; i < m ; i++) {
        for(int j = 0; j < m; j++) {
            result[i][j] = 0;
        }
    }
    
    if(n > m) {
        n = m;
    }
    
    if(n < 1) {
        n = 1;
    }
    int nr = m/n; // nr of elements(lines of matrix) in intervals if equal division is possible
    int rest = m % n; //nr of elements to be redistributed(if equal division is not possible
    int var = 0;
    
    //THREAD POOL
    
    ThreadPool pool(n);
    int j = 0; // start of first interval
    auto start = std::chrono::steady_clock::now();
//    while(rest > 0) {
//        int c1 = j;
//        pool.enqueue([c1, nr, a, b](){
//            multiplyMatrices(c1, c1 + nr + 1, a, b);
//           }
//        );
//        var++;
//        rest --;
//        n--;
//        j = j + nr + 1;
//    }
//
//    for(int i = 0 ; i < n ; i ++) {
//        int c2 = j;
//        pool.enqueue([c2, nr, a, b](){
//            multiplyMatrices(c2, c2 + nr, a, b);
//            }
//         );
//        j = j + nr ;
//    }
//    pool.close();
    
    // ASYNC AND FUTURE
    
    //int start_s=clock();
    std::vector<std::future<void>> futures;
    while(rest > 0) {
        int c1 = j;
        futures.push_back(std::async(multiplyMatrices, c1, c1 + nr + 1, a, b));
        var++;
        rest --;
        n--;
        j = j + nr + 1;
    }
    
    for(int i = 0 ; i < n ; i ++) {
        int c2 = j;
        futures.push_back(std::async(multiplyMatrices, c2, c2 + nr, a, b));
        j = j + nr ;
    }
    for(auto &e : futures) {
        e.get();
    }
    auto end = std::chrono::steady_clock::now();
    auto diff = end - start;
    //int stop_s=clock();
    //cout << "time: " << (stop_s-start_s)/double(CLOCKS_PER_SEC)*1000 << endl;
    std::cout << std::chrono::duration <double, std::milli> (diff).count() << " ms" << std::endl;


    return 0;
}
