package model;

/**
 * Created by andrapop on 2018-01-13.
 */
public class Pair {
    public int _first;
    public int _end;
    public Pair(int first, int end) {
        _first = first;
        _end = end;
    }
}